using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MonateBackend.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// 1. Connect to MySQL Database
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<MonateDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// 2. Setup Razor Pages (Web GUI) & API Controllers (For Android App)
builder.Services.AddRazorPages();
builder.Services.AddControllers();

// 3. Setup Session State (Crucial for the Cart to remember items)
builder.Services.AddSession(options => {
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// 4. Setup JWT Authentication (For SSO)
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
        };
    });

// 5. Setup CORS (Allows Android App to talk to your API)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAndroidApp",
        builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// IMPORTANT: Session must be placed between UseRouting and UseAuthorization
app.UseSession();

app.UseCors("AllowAndroidApp");
app.UseAuthentication(); // Enables JWT
app.UseAuthorization();

app.MapRazorPages(); // Maps the Web GUI
app.MapControllers(); // Maps the API for Android

app.Run();