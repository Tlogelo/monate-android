using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;

namespace MonateBackend.Pages
{
    public class CheckoutModel : PageModel
    {
        public List<CartItem> CartItems { get; set; }
        public decimal Total { get; set; }

        [BindProperty]
        public CheckoutFormModel Form { get; set; } = new CheckoutFormModel();

        // Guideline 5 & 15: Input controls with strict validation rules
        public class CheckoutFormModel
        {
            [Required(ErrorMessage = "Full name is required.")]
            public string FullName { get; set; }

            [Required(ErrorMessage = "Phone number is required.")]
            [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Phone number must be exactly 10 digits.")]
            public string PhoneNumber { get; set; }

            [Required(ErrorMessage = "Delivery address is required.")]
            [MinLength(5, ErrorMessage = "Address is too short.")]
            public string Address { get; set; }

            [Required]
            public string OrderType { get; set; } = "Delivery";

            public string CollectionTime { get; set; }

            [Required(ErrorMessage = "Please select a payment method.")]
            public string PaymentMethod { get; set; }
        }

        public IActionResult OnGet()
        {
            // Load cart from Session
            var cartJson = HttpContext.Session.GetString("Cart");
            CartItems = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);

            // If cart is empty, kick them back to the menu
            if (!CartItems.Any()) return RedirectToPage("/Menu");

            // Calculate total (Items + R25 Delivery Fee)
            Total = CartItems.Sum(c => c.Price * c.Quantity) + 25.00m;
            return Page();
        }

        public IActionResult OnPost()
        {
            // GUIDELINE 15: Handle invalid inputs without crashing
            if (!ModelState.IsValid)
            {
                // Reload cart data so the page doesn't break when returning
                var cartJson = HttpContext.Session.GetString("Cart");
                CartItems = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);
                Total = CartItems.Sum(c => c.Price * c.Quantity) + 25.00m;

                return Page(); // Returns the page and shows red error messages automatically
            }

            // 1. Create the new Order
            var newOrder = new Order
            {
                Id = new System.Random().Next(1000, 9999),
                Date = DateTime.Now.ToString("dd MMM yyyy, HH:mm"),
                Status = "Received",
                Total = Total,
                Items = CartItems.Select(c => new OrderItem
                {
                    Quantity = c.Quantity,
                    Name = c.Name,
                    TotalPrice = c.Price * c.Quantity
                }).ToList()
            };

            // 2. Save to Order History Session
            var orderHistoryJson = HttpContext.Session.GetString("OrderHistory");
            var orderHistory = string.IsNullOrEmpty(orderHistoryJson)
                ? new List<Order>()
                : JsonSerializer.Deserialize<List<Order>>(orderHistoryJson);

            orderHistory.Insert(0, newOrder);
            HttpContext.Session.SetString("OrderHistory", JsonSerializer.Serialize(orderHistory));

            // 3. Clear the Cart
            HttpContext.Session.Remove("Cart");

            // 4. Redirect to Orders page
            return RedirectToPage("/Orders");
        }
    }
}