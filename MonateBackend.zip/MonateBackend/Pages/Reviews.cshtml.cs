using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace MonateBackend.Pages
{
    public class ReviewsModel : PageModel
    {
        public List<OrderToReview> OrdersToReview { get; set; } = new List<OrderToReview>();
        public List<PastReview> PastReviews { get; set; } = new List<PastReview>();

        public void OnGet()
        {
            // Mock data - replace with actual database queries
            OrdersToReview = new List<OrderToReview>
            {
                new OrderToReview { Id = 1042, Date = "20 Oct 2026", Total = 375.00m }
            };

            PastReviews = new List<PastReview>
            {
                new PastReview
                {
                    ItemName = "Quarter Chicken",
                    Date = "18 Oct 2026",
                    Rating = 5,
                    Comment = "Absolutely delicious! The flame-grilled flavor is amazing. Will definitely order again."
                },
                new PastReview
                {
                    ItemName = "Solo Combo",
                    Date = "15 Oct 2026",
                    Rating = 4,
                    Comment = "Great value for money. The chips were crispy and the drink was cold."
                }
            };
        }

        public IActionResult OnPostSubmitReview(int orderId, int rating, string comment)
        {
            // TODO: Save review to database
            // TODO: Add 5 loyalty points to user's account

            TempData["Message"] = "Thank you for your review! You've earned 5 loyalty points.";
            return RedirectToPage();
        }

        public class OrderToReview
        {
            public int Id { get; set; }
            public string Date { get; set; }
            public decimal Total { get; set; }
        }

        public class PastReview
        {
            public string ItemName { get; set; }
            public string Date { get; set; }
            public int Rating { get; set; }
            public string Comment { get; set; }
        }
    }
}