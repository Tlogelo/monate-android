using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace MonateBackend.Pages
{
    public class ProfileModel : PageModel
    {
        [BindProperty]
        public UserSettings Settings { get; set; } = new UserSettings();

        [BindProperty]
        public PasswordModel Password { get; set; } = new PasswordModel();

        public class UserSettings
        {
            [Required]
            public string FullName { get; set; } = "Makwena Masenya"; // Default value
            public bool NotificationsEnabled { get; set; } = true;
            public string DefaultCollectionTime { get; set; } = "ASAP";
            public string DefaultPaymentMethod { get; set; } = "Cash";
        }

        public class PasswordModel
        {
            [Required]
            public string CurrentPassword { get; set; }

            [Required]
            // Guideline 15: Regex ensures the password meets the complexity rules
            [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z\d]).{8,}$",
                ErrorMessage = "Password must be 8+ chars with upper, lower, number and symbol.")]
            public string NewPassword { get; set; }

            [Required]
            [Compare("NewPassword", ErrorMessage = "Passwords do not match.")]
            public string ConfirmPassword { get; set; }
        }

        public void OnGet()
        {
            // Count items in cart for the navigation badge
            var cartJson = HttpContext.Session.GetString("Cart");
            var cartItems = string.IsNullOrEmpty(cartJson)
                ? new List<MonateBackend.Models.CartItem>()
                : System.Text.Json.JsonSerializer.Deserialize<List<MonateBackend.Models.CartItem>>(cartJson);

            ViewData["CartCount"] = cartItems.Sum(c => c.Quantity);

            // Load user settings from database here
        }

        // Guideline 13: Save Name
        public IActionResult OnPostSaveName()
        {
            if (!ModelState.IsValid) return Page(); // Prevents crash on invalid input
            // TODO: Save Settings.FullName to database
            TempData["Message"] = "Name updated successfully!";
            return RedirectToPage();
        }

        // Guideline 11 & 15: Update Password securely
        public IActionResult OnPostUpdatePassword()
        {
            if (!ModelState.IsValid)
            {
                // If regex fails or passwords don't match, reload page safely with red error messages
                return Page();
            }

            // TODO: 
            // 1. Check if CurrentPassword matches the one in the database.
            // 2. Hash the NewPassword using BCrypt.
            // 3. Save the new hash to the database.

            TempData["Message"] = "Password updated successfully!";
            return RedirectToPage();
        }

        // Guideline 13: Update Settings
        public IActionResult OnPostUpdateSettings()
        {
            if (!ModelState.IsValid) return Page();
            // TODO: Save Settings.NotificationsEnabled, DefaultCollectionTime, etc. to database
            return RedirectToPage();
        }

        public IActionResult OnPostLogout()
        {
            // Clears the login session AND the cart/order history
            HttpContext.Session.Clear();

            // Redirects back to Login
            return RedirectToPage("/Auth/Login");
        }
    }
}