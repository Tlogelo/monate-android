using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace MonateBackend.Pages
{
    public class LoyaltyModel : PageModel
    {
        public int PointsBalance { get; set; } = 0;
        public List<PointHistory> PointsHistory { get; set; } = new List<PointHistory>();

        public void OnGet()
        {
            // TODO: Load actual points from database
            // For demo, using mock data
            PointsBalance = 75; // Example balance

            PointsHistory = new List<PointHistory>
            {
                new PointHistory { Date = "20 Oct 2026", Description = "Order #1042", Points = 38 },
                new PointHistory { Date = "18 Oct 2026", Description = "Order #1041", Points = 10 },
                new PointHistory { Date = "15 Oct 2026", Description = "Review: Quarter Chicken", Points = 5 },
                new PointHistory { Date = "10 Oct 2026", Description = "Order #1040", Points = 22 }
            };
        }

        public class PointHistory
        {
            public string Date { get; set; }
            public string Description { get; set; }
            public int Points { get; set; }
        }
    }
}