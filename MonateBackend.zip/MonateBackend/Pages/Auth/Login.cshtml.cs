using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace MonateBackend.Pages.Auth
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            [Required, EmailAddress]
            public string Email { get; set; }

            [Required]
            public string Password { get; set; }
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) return Page();

            // TODO: Add your real database/Firebase password check here later.
            // For the prototype, we accept any login to show the flow.

            // SAVE USER TO SESSION (This marks them as logged in)
            HttpContext.Session.SetString("UserEmail", Input.Email);

            // REDIRECT TO HOME PAGE
            return RedirectToPage("/Index");
        }
    }
}