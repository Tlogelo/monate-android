﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace MonateBackend.Pages
{
    public class MenuModel : PageModel
    {
        public List<MenuItem> MenuItems { get; set; } = new List<MenuItem>();
        public List<string> Categories { get; set; } = new List<string>();
        public string CurrentCategory { get; set; } = "All";

        public void OnGet(string category)
        {
            // 1. Define all categories for the filter buttons
            Categories = new List<string>
            {
                "All", "Burgers", "Chicken", "Combos", "Desserts",
                "Drinks", "Pizza", "Sides", "Steak", "Wings", "Wraps"
            };

            // 2. Set current category (default to "All" if none provided)
            CurrentCategory = string.IsNullOrEmpty(category) ? "All" : category;

            // 3. Load all menu items (Mock data matching your app)
            var allItems = new List<MenuItem>
            {
                new MenuItem { Id = 1, Category = "Chicken", Name = "Quarter Chicken", Description = "Flame-grilled chicken with your choice of side.", Price = 75.00m, Emoji = "🍗" },
                new MenuItem { Id = 2, Category = "Chicken", Name = "Half Chicken", Description = "Half a flame-grilled chicken with your choice of side.", Price = 130.00m, Emoji = "🍗" },
                new MenuItem { Id = 3, Category = "Steak", Name = "Rump 300g", Description = "Juicy rump steak served with a side.", Price = 180.00m, Emoji = "🥩" },
                new MenuItem { Id = 4, Category = "Steak", Name = "Fillet 250g", Description = "Tender fillet steak served with a side.", Price = 165.00m, Emoji = "🥩" },
                new MenuItem { Id = 5, Category = "Steak", Name = "T-Bone 400g", Description = "Flame-grilled T-bone served with a side.", Price = 220.00m, Emoji = "🥩" },
                new MenuItem { Id = 6, Category = "Wings", Name = "6 Wings", Description = "Peri-peri wings served with a side.", Price = 95.00m, Emoji = "🍖" },
                new MenuItem { Id = 7, Category = "Wings", Name = "12 Wings", Description = "A dozen peri-peri wings served with a side.", Price = 175.00m, Emoji = "🍖" },
                new MenuItem { Id = 8, Category = "Burgers", Name = "Cheese Burger", Description = "Beef patty, cheese, lettuce, tomato & sauce.", Price = 55.00m, Emoji = "🍔" },
                new MenuItem { Id = 9, Category = "Burgers", Name = "Double Cheese Burger", Description = "Two beef patties, double cheese & sauce.", Price = 79.00m, Emoji = "🍔" },
                new MenuItem { Id = 10, Category = "Burgers", Name = "Crumbed Burger", Description = "Crumbed breast fillet, lettuce, mayo & tomato.", Price = 60.00m, Emoji = "🍔" },
                new MenuItem { Id = 11, Category = "Combos", Name = "Solo Combo", Description = "Quarter chicken, chips and a 330ml drink.", Price = 99.00m, Emoji = "🍱" },
                new MenuItem { Id = 12, Category = "Combos", Name = "Family Combo", Description = "Whole chicken, large chips and a 2L cold drink.", Price = 320.00m, Emoji = "🍱" },
                new MenuItem { Id = 13, Category = "Sides", Name = "Pap & Gravy", Description = "Traditional pap with tasty gravy.", Price = 20.00m, Emoji = "🍲" },
                new MenuItem { Id = 14, Category = "Sides", Name = "Chips", Description = "Crispy golden fried chips.", Price = 25.00m, Emoji = "" },
                new MenuItem { Id = 15, Category = "Sides", Name = "Coleslaw", Description = "Creamy homemade coleslaw.", Price = 18.00m, Emoji = "🥗" },
                new MenuItem { Id = 16, Category = "Pizza", Name = "Margherita Pizza", Description = "Cheese & tomato classic pizza.", Price = 85.00m, Emoji = "🍕" },
                new MenuItem { Id = 17, Category = "Pizza", Name = "Pepperoni Pizza", Description = "Pepperoni, cheese & tomato pizza.", Price = 95.00m, Emoji = "🍕" },
                new MenuItem { Id = 18, Category = "Wraps", Name = "Chicken Wrap", Description = "Grilled chicken with lettuce & sauce.", Price = 65.00m, Emoji = "🌯" },
                new MenuItem { Id = 19, Category = "Wraps", Name = "Steak Wrap", Description = "Strips of grilled steak with lettuce & sauce.", Price = 75.00m, Emoji = "🌯" },
                new MenuItem { Id = 20, Category = "Desserts", Name = "Malva Pudding", Description = "Traditional Malva pudding & custard.", Price = 28.00m, Emoji = "🍮" },
                new MenuItem { Id = 21, Category = "Desserts", Name = "Ice Cream Cup", Description = "Vanilla ice cream with chocolate sauce.", Price = 25.00m, Emoji = "🍦" },
                new MenuItem { Id = 22, Category = "Drinks", Name = "Coca Cola 330ml", Description = "Refreshing Coca Cola soft drink.", Price = 20.00m, Emoji = "" },
                new MenuItem { Id = 23, Category = "Drinks", Name = "Sprite 330ml", Description = "Refreshing Sprite soft drink.", Price = 20.00m, Emoji = "🥤" },
                new MenuItem { Id = 24, Category = "Drinks", Name = "Still Water 500ml", Description = "Bottled still water.", Price = 15.00m, Emoji = "💧" },
                new MenuItem { Id = 25, Category = "Drinks", Name = "Fanta Orange 330ml", Description = "Refreshing Fanta Orange soft drink.", Price = 20.00m, Emoji = "🥤" }
            };

            // 4. FILTER THE LIST based on the selected category
            if (CurrentCategory == "All")
            {
                MenuItems = allItems;
            }
            else
            {
                MenuItems = allItems.Where(i => i.Category == CurrentCategory).ToList();
            }
        }

        // Add to Cart logic (Same as before)
        public IActionResult OnPostAddToCart(int itemId)
        {
            var item = MenuItems.FirstOrDefault(i => i.Id == itemId);
            if (item != null)
            {
                var cartJson = HttpContext.Session.GetString("Cart");
                var cart = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);

                var existingItem = cart.FirstOrDefault(i => i.Id == item.Id);
                if (existingItem != null) existingItem.Quantity++;
                else cart.Add(new CartItem { Id = item.Id, Name = item.Name, Price = item.Price, Quantity = 1, Emoji = item.Emoji });

                HttpContext.Session.SetString("Cart", JsonSerializer.Serialize(cart));
            }
            // Redirect back to the same category so the filter stays active
            return RedirectToPage(new { category = CurrentCategory });
        }

        public class MenuItem
        {
            public int Id { get; set; }
            public string Category { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public decimal Price { get; set; }
            public string Emoji { get; set; }
        }
    }
}