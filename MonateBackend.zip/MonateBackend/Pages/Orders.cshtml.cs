using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.Collections.Generic;
using System.Text.Json;

namespace MonateBackend.Pages
{
    public class OrdersModel : PageModel
    {
        public List<Order> Orders { get; set; } = new List<Order>();

        public void OnGet()
        {
            // Count items in cart for the navigation badge
            var cartJson = HttpContext.Session.GetString("Cart");
            var cartItems = string.IsNullOrEmpty(cartJson)
                ? new List<MonateBackend.Models.CartItem>()
                : System.Text.Json.JsonSerializer.Deserialize<List<MonateBackend.Models.CartItem>>(cartJson);

            ViewData["CartCount"] = cartItems.Sum(c => c.Quantity);

            // Read Order History from Session Memory
            var orderHistoryJson = HttpContext.Session.GetString("OrderHistory");

            if (!string.IsNullOrEmpty(orderHistoryJson))
            {
                Orders = JsonSerializer.Deserialize<List<Order>>(orderHistoryJson);
            }
            // If the session is empty, Orders remains an empty list, 
            // which will automatically trigger the "No orders yet" UI in the HTML!
        }
    }
}