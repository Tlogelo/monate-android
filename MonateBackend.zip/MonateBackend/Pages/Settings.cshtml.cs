using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.ComponentModel.DataAnnotations;

namespace MonateBackend.Pages
{
    public class SettingsModel : PageModel
    {
        private readonly MonateDbContext _context;
        public SettingsModel(MonateDbContext context) { _context = context; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            // GUIDELINE 15: Data annotations handle invalid inputs automatically without crashing
            [Required, RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Phone must be exactly 10 digits.")]
            public string Phone { get; set; }

            [Required, MinLength(5, ErrorMessage = "Address is too short.")]
            public string Address { get; set; }
        }

        public void OnGet()
        {
            // Load current user data from DB into Input model
            // var user = _context.Users.Find(currentUserId);
            // Input = new InputModel { Phone = user.Phone, Address = user.Address };
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); // Reloads page and shows red error messages automatically
            }

            // TODO: Update user in database with Input.Phone and Input.Address
            // _context.SaveChanges();

            return RedirectToPage("/Index");
        }
    }
}