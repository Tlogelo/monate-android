using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MonateBackend.Pages
{
    public class HelpModel : PageModel
    {
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            // TODO: Save support ticket to database
            // TODO: Send email to support team

            TempData["Message"] = "Thank you for your message. We'll get back to you within 24 hours.";
            return RedirectToPage();
        }
    }
}