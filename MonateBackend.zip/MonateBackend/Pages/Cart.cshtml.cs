﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;

namespace MonateBackend.Pages
{
    public class CartModel : PageModel
    {
        public List<CartItem> CartItems { get; set; } = new List<CartItem>();
        public decimal Subtotal { get; set; }
        public decimal DeliveryFee { get; set; } = 25.00m;
        public decimal Total { get; set; }

        [BindProperty]
        public CheckoutModel Checkout { get; set; } = new CheckoutModel();

        public class CheckoutModel
        {
            public string CollectionTime { get; set; }
            [Required(ErrorMessage = "Please select a payment method.")]
            public string PaymentMethod { get; set; }
        }

        public void OnGet()
        {
            var cartJson = HttpContext.Session.GetString("Cart");
            CartItems = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);
            CalculateTotals();
        }

        public IActionResult OnPostUpdateQuantity(int itemId, int newQty)
        {
            var cartJson = HttpContext.Session.GetString("Cart");
            var cart = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);

            if (newQty < 1) cart.RemoveAll(i => i.Id == itemId);
            else
            {
                var item = cart.FirstOrDefault(i => i.Id == itemId);
                if (item != null) item.Quantity = newQty;
            }

            HttpContext.Session.SetString("Cart", JsonSerializer.Serialize(cart));
            return RedirectToPage();
        }

        public IActionResult OnPostRemoveItem(int itemId)
        {
            var cartJson = HttpContext.Session.GetString("Cart");
            var cart = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);
            cart.RemoveAll(i => i.Id == itemId);
            HttpContext.Session.SetString("Cart", JsonSerializer.Serialize(cart));
            return RedirectToPage();
        }

        // THIS IS THE MAGIC PART: SAVING THE ORDER
        public IActionResult OnPostPlaceOrder()
        {
            if (!ModelState.IsValid) return Page();
            if (!CartItems.Any()) return Page();

            // 1. Create the new Order object
            var newOrder = new Order
            {
                Id = new System.Random().Next(1000, 9999), // Generate random Order ID
                Date = DateTime.Now.ToString("dd MMM yyyy, HH:mm"),
                Status = "Received", // Initial status as per your project plan
                Total = Total,
                Items = CartItems.Select(c => new OrderItem
                {
                    Quantity = c.Quantity,
                    Name = c.Name,
                    TotalPrice = c.Price * c.Quantity
                }).ToList()
            };

            // 2. Get existing order history from Session
            var orderHistoryJson = HttpContext.Session.GetString("OrderHistory");
            var orderHistory = string.IsNullOrEmpty(orderHistoryJson)
                ? new List<Order>()
                : JsonSerializer.Deserialize<List<Order>>(orderHistoryJson);

            // 3. Add new order to the top of the list and save back to Session
            orderHistory.Insert(0, newOrder);
            HttpContext.Session.SetString("OrderHistory", JsonSerializer.Serialize(orderHistory));

            // 4. Clear the Cart
            HttpContext.Session.Remove("Cart");

            // 5. Redirect to Orders page
            return RedirectToPage("/Orders");
        }

        private void CalculateTotals()
        {
            Subtotal = CartItems.Sum(i => i.Price * i.Quantity);
            Total = Subtotal + DeliveryFee;
        }
    }
}