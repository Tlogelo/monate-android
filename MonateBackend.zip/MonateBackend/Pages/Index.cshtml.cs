using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MonateBackend.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace MonateBackend.Pages
{
    public class IndexModel : PageModel
    {
        public IActionResult OnGet()
        {
            // 1. CHECK IF LOGGED IN: If no email is in the session, redirect to Login
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserEmail")))
            {
                return RedirectToPage("/Auth/Login");
            }

            // 2. Count items in cart for the navigation badge
            var cartJson = HttpContext.Session.GetString("Cart");
            var cartItems = string.IsNullOrEmpty(cartJson)
                ? new List<CartItem>()
                : JsonSerializer.Deserialize<List<CartItem>>(cartJson);

            ViewData["CartCount"] = cartItems.Sum(c => c.Quantity);

            return Page(); // Show the Home page if they are logged in
        }
    }
}