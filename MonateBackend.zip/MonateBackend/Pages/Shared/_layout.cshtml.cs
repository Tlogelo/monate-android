using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MonateBackend.Pages.Shared
{
    public class _layoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
