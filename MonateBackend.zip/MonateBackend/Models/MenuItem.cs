﻿using Microsoft.AspNetCore.Mvc;

namespace MonateBackend.Models
{
    public class MenuItem : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
