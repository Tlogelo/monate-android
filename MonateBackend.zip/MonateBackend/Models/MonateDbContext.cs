﻿using Microsoft.EntityFrameworkCore;

namespace MonateBackend.Models
{
    public class MonateDbContext : DbContext
    {
        public MonateDbContext(DbContextOptions<MonateDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
    }
}