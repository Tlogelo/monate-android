﻿using System.Collections.Generic;

namespace MonateBackend.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Date { get; set; }
        public string Status { get; set; } // Received, Preparing, Ready, Delivered
        public decimal Total { get; set; }
        public List<OrderItem> Items { get; set; }
    }

    public class OrderItem
    {
        public int Quantity { get; set; }
        public string Name { get; set; }
        public decimal TotalPrice { get; set; }
    }
}