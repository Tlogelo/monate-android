﻿using Microsoft.AspNetCore.Mvc;

namespace MonateBackend.API
{
    public class MenuController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
