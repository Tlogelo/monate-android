﻿using Microsoft.AspNetCore.Mvc;

namespace MonateBackend.API
{
    public class AuthController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
